package com.example.nikki.rumusfisika;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Rumus extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private ListView listView;
    private String[] list = new String[]{"Gerak","Massa Jenis","Pemuaian","Suhu dan kalor",
                                         "Tata surya","Energi","Gaya dan tekanan","Usaha",
                                         "Getaran, gelombang dan bunyi","Cahaya","Alat optik",
                                         "Rangkaian listrik","Impuls dan momentum","Medan, kuat medan, dan energi potensial listrik",
                                         "Kapasitor","Rangkaian arus bolak-balik","Medan magnet","Induksi elektromagnet","Usaha dan energi",
                                         "Vektor","Relativitas","Fisika atom","Gelombang elektromagnetik","Dualisme gelombang partikel",
                                         "Teori kinetik gas","Termodinamika","Radioaktivitas","Dinamika rotasi","Kesetimbangan benda tegar",
                                         "Mekanika fluida","Atom, Ion, Molekul"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rumus);
        getSupportActionBar().setTitle("List Rumus");
        listView = (ListView) findViewById(R.id.listRumus);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Rumus.this, android.R.layout.simple_list_item_1, android.R.id.text1, list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = null;
        if (list[position].equals("Gerak")){
            intent = new Intent(this, gerak.class);
            startActivity(intent);
        } else if (list[position].equals("Massa Jenis")) {
            intent = new Intent(this, masajenis.class);
            startActivity(intent);
        }else if (list[position].equals("Pemuaian")){
            intent = new Intent(this,pemuaian.class);
            startActivity(intent);
        }
    }
}
