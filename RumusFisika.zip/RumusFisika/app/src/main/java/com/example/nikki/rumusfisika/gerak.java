package com.example.nikki.rumusfisika;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class gerak extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerak);

        View gambar = findViewById(R.id.gambar2);
        gambar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

    }
}
