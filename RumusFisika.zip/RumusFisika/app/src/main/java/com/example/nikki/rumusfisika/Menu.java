package com.example.nikki.rumusfisika;

import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Menu extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private ListView listView;
    private String[] list = new String[]{"Rumus","Materi","About","Exit"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        getSupportActionBar().setTitle("Menu");
        listView = (ListView) findViewById(R.id.ListMenu);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Menu.this, android.R.layout.simple_list_item_1, android.R.id.text1, list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = null;
        if (list[position].equals("Rumus")){
            intent = new Intent(this, Rumus.class);
            startActivity(intent);
        }else if (list[position].equals("Materi")){
            intent = new Intent(this, Materi.class);
            startActivity(intent);
        }else if (list[position].equals("About")){
            intent = new Intent(this, About.class);
            startActivity(intent);
        }else if (list[position].equals("Exit")){
            finish();
        }

    }
}
