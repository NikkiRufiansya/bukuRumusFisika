package com.example.nikki.rumusfisika;

import android.app.Activity;
import android.app.ListActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View gambar = findViewById(R.id.imageView);
        gambar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imageView:
                Intent menu = new Intent(this, Menu.class);
                startActivity(menu);
                break;
        }
    }
}
